library(testthat)
library(patentsview)

test_check("patentsview")
